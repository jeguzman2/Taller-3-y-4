package uniandes.dpoo.aerolinea.persistencia;

import uniandes.dpoo.aerolinea.modelo.Aerolinea;
// Interface vs Leatherface :v

public interface IPersitenciaAerolinea {
	//Metodos :v
		public void cargarAerolinea (String archivo, Aerolinea aerolinea);
		
		public void salvarAerolinea (String archivo, Aerolinea aerolinea);
		
}
