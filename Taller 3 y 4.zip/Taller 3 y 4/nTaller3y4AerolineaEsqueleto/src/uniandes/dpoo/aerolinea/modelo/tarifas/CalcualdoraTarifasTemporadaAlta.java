package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalcualdoraTarifasTemporadaAlta {
	//Atributos de esta wea
	
		protected int COSTO_POR_KM = 1000;

		
		//Metodos de esto XD
		
		public int calcularCostoBase (Vuelo vuelo, Cliente cliente) {
			
			
			return 0;
			
		}
		
		public double calcularPorcentajeDescuento (Cliente cliente) {
			
			
			return 0;
			
		}
}
