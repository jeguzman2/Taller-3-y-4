package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente {
	//Atributos de esta wea
		public static String NATURAL = "Natural";
		
		private String	nombre;		
			
		//Constructor de esto
		public ClienteNatural (String	nombre) {
			
			this.nombre=nombre;
		}
		
		//Metodos de esto
		public String getTipoCliente() {
			
			return NATURAL;
		}
		
		public String getIdentificador() {
			
			return null;
		}
}
