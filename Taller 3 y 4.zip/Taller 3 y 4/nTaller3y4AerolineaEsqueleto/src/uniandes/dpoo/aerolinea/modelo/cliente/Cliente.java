package uniandes.dpoo.aerolinea.modelo.cliente;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;
import uniandes.dpoo.aerolinea.vuelos.Vuelo;

public abstract class Cliente {
	public Cliente() {
		
	}
	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	public void agegarTiquete(Tiquete tiquete) {
	}
	{
		
	}
	public int calcularValorTotalTiquetes() {
		return 0;
	}
	
	public void usarTiquetes(Vuelo vuelo) {
	
		
	}
	
}
